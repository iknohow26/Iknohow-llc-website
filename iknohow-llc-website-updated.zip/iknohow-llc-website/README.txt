IKNOHOW LLC WEBSITE
====================

FILES
- index.html: website content and page structure
- styles.css: colors, layout, typography, and mobile styling
- script.js: mobile navigation and automatic copyright year
- iknohow-do-you-logo.jpeg: supplied Iknohow Do You logo
- iknohow-women-logo.jpeg: supplied Iknohow Women logo

CONTACT DETAILS ADDED
- Phone: (586) 571-6157
- Instagram: @Iknohow_ceo

PREVIEW
Open index.html in a browser to preview the website.

PUBLISH FREE WITH GITHUB PAGES
1. Create or sign in to a free account at https://github.com
2. Create a new public repository named exactly: iknohow-llc-website
3. Upload ALL files in this folder to the repository's main branch.
   Keep both logo image files in the same folder as index.html.
4. Open the repository's Settings > Pages.
5. Under Build and deployment, choose "Deploy from a branch".
6. Choose branch "main" and folder "/ (root)", then Save.
7. Wait a few minutes. Your website address will be:
   https://YOUR-GITHUB-USERNAME.github.io/iknohow-llc-website/

NOTES
- GitHub Pages hosting is free for public repositories.
- A custom domain name (such as iknohow.com) usually costs extra.
- The phone link calls your number on compatible devices.
- The Instagram link opens https://www.instagram.com/Iknohow_ceo/.
